SAWARIYA TOURS WEBSITE — QUICK START (Hindi)

इस ZIP में:
- index.html: आपकी responsive taxi website
- robots.txt: search engine crawlers को allow करता है

वेबसाइट में:
- Sawariya Tours, Jaipur
- Call button: +91 82909 24991
- WhatsApp booking form (ग्राहक की जानकारी WhatsApp message में खुलेगी)
- Local, Airport, Outstation, One-Way, Round Trip और Railway Station pickup services
- Basic SEO title, description और TaxiService structured data

महत्वपूर्ण:
1. अभी यह website files तैयार हैं; वेबसाइट इंटरनेट पर LIVE नहीं हुई है।
2. इसे मुफ्त static hosting पर publish करना होगा। Free plan/limits समय के साथ बदल सकते हैं।
3. Publish होने के बाद असली website URL को Google Search Console में जोड़ें और ownership verify करें।
4. Google में दिखने या पहले पेज पर आने की गारंटी नहीं होती। Indexing में समय लग सकता है।
5. अपने business का सही पता, working hours, vehicle details, photos और actual service area उपलब्ध होने पर website पर जोड़ें।
6. Google Business Profile भी बनाएं/claim करें और business details website से match रखें।
7. अपना domain (जैसे sawariyatours.in) लेना optional है; custom domain आमतौर पर मुफ्त नहीं होता।

अगला कदम:
- ZIP को अपने कंप्यूटर में extract करें।
- किसी free static hosting service में index.html और robots.txt upload करें।
- Publish होने के बाद public URL को Google Search Console में verify करें।
- उसी URL के आधार पर sitemap.xml बनाकर Search Console में submit करें।

WhatsApp link इस नंबर पर सेट है: 918290924991
यदि business WhatsApp नंबर बदलना हो, index.html में 918290924991 को नए country-code सहित नंबर से बदलें।
